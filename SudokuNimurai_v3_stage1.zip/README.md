# Sudoku Nimurai — Stage 1
Co zawiera:
- licznik czasu + zapisywanie **Best Times** (Challenge: Easy/Medium/Hard; Armageddon),
- animacja **Samurai Slash** przy nowym rekordzie,
- generator plansz per trudność (unikalne rozwiązanie),
- tryby: **Zen / Challenge / Armageddon**,
- **4 języki**: EN (default) / PL / DE / FR (flagi w menu),
- podpowiedź po **30s wideo** (YouTube kanał DreamyValeMusic) – WebView z licznikem,
- armagedon: co 60s losowy efekt (2 znikające cyfry / 2 płonące pola / mgła),
- tło sakura + logo (shuriken).

## Jak zbudować APK
1) Utwórz repo na GitHub i wgraj **całą zawartość** tego katalogu (wraz z `app/` i `.github/`).  
2) W zakładce **Actions** uruchom workflow **Android CI (Build APK)**.  
3) Pobierz artefakt `sudoku-nimurai-apk` → `app-debug.apk`.

## Następny etap
- Daily Nimurai z ziarnem daty + nagrody (koban),
- waluta + sklep + skórki + złote tło,
- pełne osiągnięcia (20) + toast/baner,
- tryb fabularny (30 poziomów, bossowie 10/20/30) + palety i muzyczne warianty.
