package com.nimurai.sudoku

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.random.Random

// DataStore
val Context.dataStore by preferencesDataStore(name = "nimurai_store")
object Keys {
    val LANGUAGE = stringPreferencesKey("language")
    val BEST_EASY = longPreferencesKey("best_easy")
    val BEST_MEDIUM = longPreferencesKey("best_medium")
    val BEST_HARD = longPreferencesKey("best_hard")
    val BEST_ARMAGEDDON = longPreferencesKey("best_armageddon")
}

// I18N
enum class Lang { EN, PL, DE, FR }
data class Strings(
    val appName: String,
    val zen: String, val challenge: String, val armageddon: String,
    val play: String, val bestTimes: String, val settings: String,
    val time: String, val hint: String, val newGame: String, val erase: String,
    val chooseDifficulty: String, val easy: String, val medium: String, val hard: String,
    val watchAd: String, val claimHint: String, val skipIn: String, val noInternet: String,
    val creator: String,
    val zenDesc: String, val challengeDesc: String, val armageddonDesc: String
)
fun strings(lang: Lang) = when(lang) {
    Lang.EN -> Strings(
        "Sudoku Nimurai", "Zen", "Challenge", "Armageddon",
        "Play", "Best Times", "Settings",
        "Time", "Hint", "New game", "Erase",
        "Choose difficulty", "Easy", "Medium", "Hard",
        "Watch 30s video for a hint", "Claim hint", "Skip in", "No internet",
        "Creator: I AM SEO Paweł Kokot",
        "Relax and breathe. No timer.", "Finish as fast as you can.", "Every minute chaos strikes!"
    )
    Lang.PL -> Strings(
        "Sudoku Nimurai", "Zen", "Wyzwanie", "Armagedon",
        "Graj", "Najlepsze czasy", "Ustawienia",
        "Czas", "Podpowiedź", "Nowa gra", "Wyczyść",
        "Wybierz poziom trudności", "Łatwy", "Średni", "Trudny",
        "Obejrzyj 30s film za podpowiedź", "Odbierz podpowiedź", "Pomiń za", "Brak internetu",
        "I AM SEO Paweł Kokot",
        "Relaks i oddech. Bez czasu.", "Ukończ jak najszybciej.", "Co minutę chaos!"
    )
    Lang.DE -> Strings(
        "Sudoku Nimurai", "Zen", "Herausforderung", "Armageddon",
        "Spielen", "Bestzeiten", "Einstellungen",
        "Zeit", "Tipp", "Neues Spiel", "Löschen",
        "Schwierigkeitsgrad wählen", "Leicht", "Mittel", "Schwer",
        "30s-Video für einen Tipp ansehen", "Tipp erhalten", "Überspringen in", "Keine Internetverbindung",
        "I AM SEO Paweł Kokot",
        "Entspannen und atmen. Kein Timer.", "So schnell wie möglich abschließen.", "Jede Minute Chaos!"
    )
    Lang.FR -> Strings(
        "Sudoku Nimurai", "Zen", "Défi", "Armageddon",
        "Jouer", "Meilleurs temps", "Paramètres",
        "Temps", "Indice", "Nouvelle partie", "Effacer",
        "Choisir la difficulté", "Facile", "Moyen", "Difficile",
        "Regarder 30s de vidéo pour un indice", "Obtenir l'indice", "Passer dans", "Pas d'internet",
        "I AM SEO Paweł Kokot",
        "Détends-toi et respire. Pas de chrono.", "Finis le plus vite possible.", "Chaos chaque minute !"
    )
}

// Theme
@Composable
fun NimuraiTheme(content: @Composable () -> Unit) {
    val scheme = lightColorScheme(
        primary = Color(0xFF8C2F39),
        secondary = Color(0xFF2E5947),
        background = Color(0xFFFAF4EB),
        surface = Color(0xFFFCF7F0),
        onSurface = Color(0xFF201A14),
        outline = Color(0xFFD7C6B3),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

enum class Difficulty { EASY, MEDIUM, HARD }
enum class Mode { ZEN, CHALLENGE, ARMAGEDDON }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NimuraiApp() }
    }
}

@Composable
fun NimuraiApp() {
    NimuraiTheme {
        val ctx = LocalContext.current
        var lang by remember { mutableStateOf(Lang.EN) }
        var loaded by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            val d = ctx.dataStore.data.first()
            lang = when(d[Keys.LANGUAGE]) { "PL"->Lang.PL; "DE"->Lang.DE; "FR"->Lang.FR; else->Lang.EN }
            loaded = true
        }
        if (!loaded) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } ; return@NimuraiTheme }

        var screen by remember { mutableStateOf("menu") }
        var mode by remember { mutableStateOf(Mode.CHALLENGE) }

        when (screen) {
            "menu" -> MainMenu(lang,
                onLang = {
                    lang = it
                    LaunchedEffect(Unit) { ctx.dataStore.edit { st -> st[Keys.LANGUAGE] = it.name } }
                },
                onStart = { m -> mode = m; screen = "game" },
                onBest = { screen = "best" }
            )
            "game" -> GameScreen(lang, mode, onBack = { screen = "menu" })
            "best" -> BestTimesScreen(lang, onBack = { screen = "menu" })
        }
    }
}

@Composable
fun MainMenu(lang: Lang, onLang:(Lang)->Unit, onStart:(Mode)->Unit, onBest:()->Unit) {
    val s = strings(lang)
    Box(Modifier.fillMaxSize()) {
        SakuraBackground(true, 0.25f)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                LogoTitle(s.appName)
                Spacer(Modifier.weight(1f))
                // flags
                val flags = listOf("🇬🇧" to Lang.EN, "🇵🇱" to Lang.PL, "🇩🇪" to Lang.DE, "🇫🇷" to Lang.FR)
                flags.forEach { (emoji, l) ->
                    TextButton(onClick = { onLang(l) }) { Text(emoji, fontSize = 20.sp) }
                }
            }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModeCard(title=s.zen, desc=s.zenDesc) { onStart(Mode.ZEN) }
                    ModeCard(title=s.challenge, desc=s.challengeDesc) { onStart(Mode.CHALLENGE) }
                    ModeCard(title=s.armageddon, desc=s.armageddonDesc) { onStart(Mode.ARMAGEDDON) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(onClick = onBest, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Timer, null); Spacer(Modifier.width(8.dp)); Text(s.bestTimes) }
            }
            Spacer(Modifier.weight(1f))
            Text(s.creator, modifier = Modifier.align(Alignment.End), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ModeCard(title:String, desc:String, onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text(desc, fontSize = 12.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
fun LogoTitle(name:String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(0.9f)), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(30.dp)) {
                val c = center; val r = size.minDimension/2.6f
                for (i in 0..3) {
                    val a = i* (Math.PI/2).toFloat()
                    drawLine(Color.White, start=c, end= androidx.compose.ui.geometry.Offset(c.x + r* kotlin.math.cos(a), c.y + r* kotlin.math.sin(a)), strokeWidth = 4f)
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(name, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
    }
}

// Game
@Composable
fun GameScreen(lang: Lang, mode: Mode, onBack:()->Unit) {
    val s = strings(lang)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var difficulty by remember { mutableStateOf(Difficulty.EASY) }
    var puzzle by remember(mode, difficulty) { mutableStateOf(generatePuzzle(difficulty)) }
    var board by remember(puzzle) { mutableStateOf(copyGrid(puzzle.first)) }
    val given = remember(puzzle) { computeGiven(puzzle.first) }
    var selected by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var elapsed by remember { mutableStateOf(0L) }
    var running by remember { mutableStateOf(mode != Mode.ZEN) }
    var fires by remember { mutableStateOf(setOf<Pair<Int,Int>>()) }
    var chaosCountdown by remember { mutableStateOf(60) }
    var showRecordAnim by remember { mutableStateOf(false) }

    // BGM
    val bgm = remember { MediaPlayer.create(ctx, R.raw.nimurai_bgm).apply { isLooping = true; setVolume(0.35f,0.35f) } }
    DisposableEffect(Unit) { bgm.start(); onDispose { bgm.release() } }

    // Timer & Armageddon
    LaunchedEffect(running) {
        while (running) {
            delay(1000); elapsed += 1
            if (mode == Mode.ARMAGEDDON) {
                chaosCountdown -= 1
                if (chaosCountdown <= 0) {
                    val event = listOf("HIDE2","FIRE2","MIST").random()
                    when(event){
                        "HIDE2" -> hideTwo(board, given)
                        "FIRE2" -> fires = pickTwo(board, given).toSet()
                        "MIST" -> Unit // visual handled below as overlay
                    }
                    chaosCountdown = 60
                }
            }
        }
    }

    fun resetGame() {
        puzzle = generatePuzzle(difficulty); board = copyGrid(puzzle.first); elapsed = 0; running = mode != Mode.ZEN; fires = emptySet(); chaosCountdown = 60
    }

    fun placeNumber(n:Int) {
        val pos = selected ?: return
        val (r,c) = pos; if (given[r][c]) return
        if (n==0) { board[r][c]=0; return }
        val sol = puzzle.second
        if (sol[r][c]==n) {
            board[r][c]=n
            if (isSolved(board)) {
                running = false
                // save best
                scope.launch {
                    val key = when(mode){
                        Mode.CHALLENGE -> when(difficulty){ Difficulty.EASY->Keys.BEST_EASY; Difficulty.MEDIUM->Keys.BEST_MEDIUM; Difficulty.HARD->Keys.BEST_HARD }
                        Mode.ARMAGEDDON -> Keys.BEST_ARMAGEDDON
                        else -> Keys.BEST_EASY
                    }
                    val d = ctx.dataStore.data.first()
                    val best = d[key] ?: Long.MAX_VALUE
                    if (elapsed < best) {
                        ctx.dataStore.edit { it[key] = elapsed }
                        showRecordAnim = true
                        delay(1500)
                        showRecordAnim = false
                    }
                }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        SakuraBackground(true, 0.2f)
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Text("${s.time}: " + formatTime(elapsed), fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (mode != Mode.ZEN) {
                    AssistChip(onClick = { running = !running }, label = { Text(if (running) "Pause" else "Resume") }, leadingIcon = { Icon(Icons.Default.Pause, null) })
                }
            }
            if (mode == Mode.CHALLENGE) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected=difficulty==Difficulty.EASY, onClick={ difficulty=Difficulty.EASY; resetGame() }, label={ Text(s.easy) })
                    FilterChip(selected=difficulty==Difficulty.MEDIUM, onClick={ difficulty=Difficulty.MEDIUM; resetGame() }, label={ Text(s.medium) })
                    FilterChip(selected=difficulty==Difficulty.HARD, onClick={ difficulty=Difficulty.HARD; resetGame() }, label={ Text(s.hard) })
                }
            }
            if (mode == Mode.ARMAGEDDON) {
                Text("Armageddon: ${'$'}chaosCountdown s")
            }
            SudokuGrid(board, given, selected, onSelect={ selected=it }, fires=fires, onExtinguish={ fires = fires - it })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                HintButton(lang) {
                    val e = firstEmpty(board); if (e!=null) { val (r,c)=e; board[r][c]=puzzle.second[r][c] }
                }
                Row {
                    OutlinedButton(onClick = { val pos=selected; if (pos!=null){ val (r,c)=pos; if(!given[r][c]) board[r][c]=0 } }) { Text(s.erase) }
                    Spacer(Modifier.width(6.dp))
                    Button(onClick = { resetGame() }) { Text(s.newGame) }
                }
            }
            Numpad(onNumber={ placeNumber(it) })
        }
        if (mode==Mode.ARMAGEDDON && chaosCountdown>50 && chaosCountdown<55) { // brief mist overlay after event
            Canvas(Modifier.fillMaxSize().alpha(0.25f)) { drawRect(Color(0xFFBBBBBB)) }
        }
        if (showRecordAnim) SamuraiSlash()
    }
}

// Armageddon helpers
fun hideTwo(board:Array<IntArray>, given:Array<BooleanArray>) {
    val cells = mutableListOf<Pair<Int,Int>>()
    for (r in 0 until 9) for (c in 0 until 9) if (!given[r][c] && board[r][c]!=0) cells += (r to c)
    cells.shuffled().take(2).forEach { (r,c) -> board[r][c]=0 }
}
fun pickTwo(board:Array<IntArray>, given:Array<BooleanArray>): List<Pair<Int,Int>> {
    val cells = mutableListOf<Pair<Int,Int>>()
    for (r in 0 until 9) for (c in 0 until 9) if (!given[r][c]) cells += (r to c)
    return cells.shuffled().take(2)
}

@Composable
fun HintButton(lang: Lang, onGranted:()->Unit) {
    val s = strings(lang)
    var show by remember { mutableStateOf(false) }
    Button(onClick = { show = true }) { Icon(Icons.Default.OndemandVideo, null); Spacer(Modifier.width(6.dp)); Text(s.hint) }
    if (show) AdHintDialog(lang, onClose = { show = false }, onDone = { onGranted(); show = false })
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdHintDialog(lang: Lang, onClose:()->Unit, onDone:()->Unit) {
    val s = strings(lang)
    val ctx = LocalContext.current
    val online = remember { isOnline(ctx) }
    var left by remember { mutableStateOf(30) }
    LaunchedEffect(Unit) { while (left>0) { delay(1000); left -= 1 } }
    AlertDialog(
        onDismissRequest = { },
        title = { Text(if (online) s.watchAd else s.noInternet) },
        text = {
            Column {
                if (online) {
                    AndroidView(factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.cacheMode = WebSettings.LOAD_DEFAULT
                            webChromeClient = WebChromeClient()
                            loadUrl("https://www.youtube.com/@DreamyValeMusic/videos")
                        }
                    }, modifier = Modifier.height(220.dp).fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("${s.skipIn}: ${'$'}left s", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                } else {
                    Text(s.noInternet)
                }
            }
        },
        confirmButton = { Button(onClick = { if (left<=0 || !online) onDone() }, enabled = (left<=0) || (!online)) { Text(s.claimHint) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val net = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(net) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

@Composable
private fun SudokuGrid(
    board: Array<IntArray>,
    given: Array<BooleanArray>,
    selected: Pair<Int, Int>?,
    onSelect: (Pair<Int, Int>) -> Unit,
    fires: Set<Pair<Int,Int>> = emptySet(),
    onExtinguish: (Pair<Int,Int>) -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            .padding(4.dp)
    ) {
        for (r in 0 until 9) {
            Row(Modifier.weight(1f)) {
                for (c in 0 until 9) {
                    val value = board[r][c]
                    val isGiven = given[r][c]
                    val isSelected = selected?.first == r && selected.second == c
                    val inSameGroup = selected?.let { (sr, sc) -> sr == r || sc == c || (sr/3 == r/3 && sc/3 == c/3) } == true
                    val bg = when {
                        isSelected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        inSameGroup -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f)
                        else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(0.5.dp, MaterialTheme.colorScheme.outline)
                            .background(bg)
                            .clickable { onSelect(r to c) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (value == 0) "" else value.toString(),
                            fontSize = 20.sp,
                            fontWeight = if (isGiven) FontWeight.Bold else FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (c == 2 || c == 5) {
                            Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(2.dp).background(MaterialTheme.colorScheme.outline))
                        }
                        if (r == 2 || r == 5) {
                            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp).background(MaterialTheme.colorScheme.outline))
                        }
                        if ((r to c) in fires) {
                            val interaction = remember { MutableInteractionSource() }
                            Box(Modifier.matchParentSize().clickable(interactionSource = interaction, indication = null) { onExtinguish(r to c) })
                            Canvas(Modifier.fillMaxSize()) {
                                val p = Path()
                                val w = size.width; val h = size.height
                                p.moveTo(w*0.5f, h*0.2f); p.quadraticBezierTo(w*0.6f, h*0.45f, w*0.5f, h*0.7f)
                                p.quadraticBezierTo(w*0.4f, h*0.45f, w*0.5f, h*0.2f)
                                drawPath(p, Color(0xAAFF6A00))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Numpad(onNumber:(Int)->Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (n in 1..9) {
                ElevatedButton(onClick = { onNumber(n) }, modifier = Modifier.weight(1f)) { Text(n.toString(), fontSize = 18.sp) }
            }
        }
    }
}

@Composable
fun SamuraiSlash() {
    val alpha = remember { Animatable(1f) }
    LaunchedEffect(Unit) { alpha.animateTo(0f, animationSpec = tween(1500, easing = LinearEasing)) }
    Canvas(Modifier.fillMaxSize().alpha(alpha.value)) {
        val path = Path()
        path.moveTo(0f, size.height*0.2f)
        path.lineTo(size.width, size.height*0.8f)
        drawPath(path, color = Color(0x99FFFFFF))
    }
}

// Background
@Composable
fun SakuraBackground(animate: Boolean, alpha: Float) {
    data class Petal(var x: Float, var y: Float, var size: Float, var speed: Float, var drift: Float)
    val petals = remember { List(40) { Petal(Random.nextFloat(), Random.nextFloat(), Random.nextFloat()*0.02f + 0.008f, Random.nextFloat()*0.02f + 0.006f, (Random.nextFloat()-0.5f)*0.02f) }.toMutableList() }
    val anim = remember { Animatable(0f) }
    LaunchedEffect(animate) {
        if (animate) {
            while (true) {
                anim.animateTo(1f, animationSpec = tween(16000, easing = LinearEasing))
                anim.snapTo(0f)
            }
        }
    }
    Canvas(Modifier.fillMaxSize().alpha(alpha)) {
        petals.forEach { p ->
            var y = p.y + p.speed * (anim.value + 0.001f)
            if (y > 1f) y -= 1f
            val x = (p.x + p.drift * anim.value).mod(1f)
            val px = x * size.width
            val py = y * size.height
            drawPath(
                path = sakuraPetalPath(px, py, size.minDimension * p.size),
                color = Color(0xFFEDA7B2)
            )
        }
    }
}
fun sakuraPetalPath(cx: Float, cy: Float, r: Float): Path {
    val path = Path()
    path.moveTo(cx, cy - r)
    path.quadraticBezierTo(cx + r, cy - r*0.3f, cx, cy + r)
    path.quadraticBezierTo(cx - r, cy - r*0.3f, cx, cy - r)
    return path
}

// Sudoku helpers + generator
fun copyGrid(src: Array<IntArray>): Array<IntArray> = Array(9) { r -> src[r].clone() }
fun computeGiven(grid: Array<IntArray>): Array<BooleanArray> = Array(9) { r -> BooleanArray(9) { c -> grid[r][c] != 0 } }
fun formatTime(sec: Long) : String = "%02d:%02d".format(sec/60, sec%60)

fun isMoveValid(board:Array<IntArray>, row:Int, col:Int, num:Int):Boolean {
    for (i in 0 until 9) { if (i!=col && board[row][i]==num) return false; if (i!=row && board[i][col]==num) return false }
    val br = row/3*3; val bc = col/3*3
    for (r in br until br+3) for (c in bc until bc+3) { if ((r!=row||c!=col) && board[r][c]==num) return false }
    return true
}
fun isSolved(board:Array<IntArray>):Boolean {
    for (r in 0 until 9) for (c in 0 until 9) if (board[r][c]==0) return false
    for (r in 0 until 9) for (c in 0 until 9) { val n=board[r][c]; if (n==0 || !isMoveValid(board,r,c,n)) return false }
    return true
}

fun generatePuzzle(diff: Difficulty): Pair<Array<IntArray>, Array<IntArray>> {
    fun copy(g:Array<IntArray>)=Array(9){r->g[r].clone()}
    fun generateFull(): Array<IntArray> {
        val g = Array(9) { IntArray(9) }
        fun ok(r:Int,c:Int,n:Int):Boolean {
            for (i in 0 until 9) if (g[r][i]==n || g[i][c]==n) return false
            val br=r/3*3; val bc=c/3*3
            for (rr in br until br+3) for (cc in bc until bc+3) if (g[rr][cc]==n) return false
            return true
        }
        fun fill(i:Int=0):Boolean {
            if (i==81) return true
            val r=i/9; val c=i%9
            if (g[r][c]!=0) return fill(i+1)
            for (n in (1..9).shuffled()) {
                if (ok(r,c,n)) { g[r][c]=n; if (fill(i+1)) return true; g[r][c]=0 }
            }
            return false
        }
        // seed diagonals
        for (b in 0..2) {
            val nums = (1..9).shuffled().toMutableList()
            for (i in 0..2) for (j in 0..2) g[b*3+i][b*3+j]=nums.removeAt(0)
        }
        fill(0); return g
    }
    fun countSolutions(grid:Array[IntArray], limit:Int=2):Int {
        val g = copy(grid)
        fun ok(r:Int,c:Int,n:Int):Boolean {
            for (i in 0 until 9) if (g[r][i]==n || g[i][c]==n) return false
            val br=r/3*3; val bc=c/3*3
            for (rr in br until br+3) for (cc in bc until bc+3) if (g[rr][cc]==n) return false
            return true
        }
        var cnt=0
        fun dfs(p:Int=0):Boolean {
            if (cnt>=limit) return true
            var i=p; while (i<81 && g[i/9][i%9]!=0) i++
            if (i==81) { cnt++; return cnt>=limit }
            val r=i/9; val c=i%9
            for (n in 1..9) { if (ok(r,c,n)) { g[r][c]=n; if (dfs(i+1)) return true; g[r][c]=0 } }
            return false
        }
        dfs(0); return cnt
    }
    val solution = generateFull()
    val grid = copy(solution)
    val removals = when(diff){ Difficulty.EASY->40; Difficulty.MEDIUM->50; Difficulty.HARD->58 }
    val cells = (0 until 81).shuffled().toMutableList()
    var removed = 0
    while (cells.isNotEmpty() && removed < removals) {
        val i = cells.removeAt(0); val r=i/9; val c=i%9
        val b = grid[r][c]; grid[r][c]=0
        // ensure uniqueness
        if (countSolutions(grid,2)!=1) grid[r][c]=b else removed++
    }
    return grid to solution
}